package com.watching.dto;

public class ListSearchVO {
	
	private String listkeyword;

	public String getListkeyword() {
		return listkeyword;
	}

	public void setListkeyword(String listkeyword) {
		this.listkeyword = listkeyword;
	}

	@Override
	public String toString() {
		return "ListSearchVO [listkeyword=" + listkeyword + "]";
	}
	

}
